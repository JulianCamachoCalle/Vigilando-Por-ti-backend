package com.VigilandoPorTi.VigilandoPorTi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VigilandoPorTiApplicationTests {

	@Test
	void contextLoads() {
	}

}
